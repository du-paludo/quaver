// Link YouTube https://youtu.be/a9g8-wYUeBA

import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
